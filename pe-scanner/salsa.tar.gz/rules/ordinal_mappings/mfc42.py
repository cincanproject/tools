mapping = {
1:'DllCanUnloadNow',
2:'DllGetClassObject',
3:'DllRegisterServer',
4:'DllUnregisterServer',
5:'?AfxLoadLibrary@@YAPEAUHINSTANCE__@@PEBD@Z',
6:'?AfxLoadLibrary@@YAPEAUHINSTANCE__@@PEBD@Z',
7:'?AfxLockGlobals@@YAXH@Z',
8:'?AfxUnlockGlobals@@YAXH@Z',
}